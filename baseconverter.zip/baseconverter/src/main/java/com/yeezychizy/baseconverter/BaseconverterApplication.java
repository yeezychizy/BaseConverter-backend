package com.yeezychizy.baseconverter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BaseconverterApplication {

	public static void main(String[] args) {
		SpringApplication.run(BaseconverterApplication.class, args);
	}

}
