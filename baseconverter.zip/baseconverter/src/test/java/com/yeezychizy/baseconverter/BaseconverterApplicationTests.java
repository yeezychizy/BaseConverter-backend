package com.yeezychizy.baseconverter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BaseconverterApplicationTests {

	@Test
	void contextLoads() {
	}

}
